package teste;

import static org.junit.Assert.*;
import lexico.Lexico;

import org.junit.Test;

public class ErrorMensageTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
    public void testErroString(){
    	Lexico umLexico = new Lexico();
    	
    }

}
