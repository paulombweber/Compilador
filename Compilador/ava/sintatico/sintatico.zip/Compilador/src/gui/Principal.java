package gui;

public class Principal {

	/**
	 * Launch the application
	 */
	public static void main(String[] args) {
		FrmCompilador frmCompilador = new FrmCompilador();
		frmCompilador.setVisible(true);
	}
	
}
